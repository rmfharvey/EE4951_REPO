README for GRB-28164_D.zip

Company Part Number: 170-28164 REV D

Date: Mon, 09 Jun 2014 15:20:43 GMT

Freescale Semiconductor
6501 William Cannon Drive West
Austin, TX 78735-8598


CAD Engineer
============
Company Contact     : Mario Velasco
Work Phone          : +52 33 32832208
Email               : mario.velascogonzalez@freescale.com

CAD Manager
===========
Company Contact     : Raymond Villalobos
Work Phone          : 512-895-6081
Email               : Raymond.Villalobos@freescale.com

Manufacturing Program Manager
=============================
Company Contact     : Jorge Garcia
Work Phone          : +52(33)3283-2309
Email               : b37464@freescale.com

Product Engineer
================
Company Contact     : Ramon Villareal
Work Phone          : +52(33)3283-2100
Email               : b14757@freescale.com
